const canvas = document.getElementById('particleCanvas');
const ctx = canvas.getContext('2d', { alpha: false });

const scenes = ['shikumen', 'arch', 'city', 'bund', 'aerial', 'detail', 'shikumen240', 'pearl120', 'compass', 'overview', 'side', 'top'];
const sources = {
  shikumen: 'assets/shikumen-photo.jpg',
  arch: 'assets/arch-skyline.jpg',
  city: 'assets/city-skyline.jpg',
  bund: 'assets/bund-night.jpg',
  aerial: 'assets/aerial-pearl.jpg',
  detail: 'assets/city-detail.jpg'
};
const labels = {
  shikumen: 'SHIKUMEN STREET',
  arch: 'ARCH + LUJIAZUI',
  city: 'CITY SKYLINE',
  bund: 'THE BUND NIGHT',
  aerial: 'AERIAL RIVER VIEW',
  detail: 'CITY DETAIL',
  shikumen240: 'SHIKUMEN VIEW / 240°',
  pearl120: 'ORIENTAL PEARL VIEW / 120°',
  compass: 'VIEW ANGLES / 0° · 120° · 240°',
  overview: 'MASTERPLAN / TOP VIEW',
  side: 'SIDE VIEW',
  top: 'TOP VIEW'
};
const particleData = window.PARTICLE_DATA || {};
let W = 0;
let H = 0;
let stream = null;

const state = {
  scene: 'shikumen',
  sceneStarted: performance.now(),
  transitionUntil: performance.now() + 650,
  particles: [],
  mouseEnabled: true,
  cameraEnabled: false,
  hand: null,
  mouse: { x: -999, y: -999, active: false, down: false },
  view: { x: 0, y: 0, targetX: 0, targetY: 0, dragging: false, lastX: 0, lastY: 0 },
  settings: { count: 48000, repel: 0.72, spring: 0.035 }
};

function resize() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  W = Math.max(1, rect.width);
  H = Math.max(1, rect.height);
  canvas.width = Math.round(W * dpr);
  canvas.height = Math.round(H * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  createParticles();
}

function randomParticle() {
  const a = Math.random() * Math.PI * 2;
  const radius = Math.sqrt(Math.random());
  return {
    x: W / 2 + Math.cos(a) * W * radius * 0.46,
    y: H / 2 + Math.sin(a) * H * radius * 0.38,
    tx: W / 2,
    ty: H / 2,
    vx: 0,
    vy: 0,
    rgb: [66, 166, 245],
    size: 0.45 + Math.random() * 1.1,
    intensity: 0.5,
    edge: false,
    water: false,
    seed: Math.random() * 100
  };
}

function createParticles() {
  state.particles = Array.from({ length: state.settings.count }, randomParticle);
  if (particleData[state.scene]) setTargetsFromData(particleData[state.scene], state.scene, true);
}

function geometryFor(data, scene) {
  const sourceWidth = data.width;
  const sourceHeight = data.height;
  const wide = ['city', 'bund', 'overview', 'side', 'top'].includes(scene);
  const fitW = wide ? 0.98 : 0.84;
  const fitH = wide ? 0.80 : 0.90;
  const scale = Math.min(W * fitW / sourceWidth, H * fitH / sourceHeight);
  return {
    sourceWidth,
    sourceHeight,
    scale,
    left: (W - sourceWidth * scale) / 2,
    top: (H - sourceHeight * scale) / 2
  };
}

function particleColor(r, g, b, scene, ratio) {
  const luminance = r * 0.2126 + g * 0.7152 + b * 0.0722;
  if (luminance < 30) return [24, 62, 112];
  if (r > g * 1.28 && r > b * 1.18) return [255, Math.min(214, 110 + g * 0.58), Math.min(170, 70 + b * 0.36)];
  if (r > g * 1.08 && g > b * 0.82 && luminance > 85) return [246, 181, 112];
  if (b > r * 1.16 || (b > g * 1.04 && luminance < 150)) return [60, 166, 255];
  if (g > r * 1.10 && g > b * 0.82) return [70, 211, 186];
  if (luminance > 205) return [238, 246, 255];
  if (['aerial', 'overview', 'top'].includes(scene) && ratio > 0.56) return [92, 205, 255];
  return [Math.min(255, r * 1.30 + 16), Math.min(255, g * 1.30 + 16), Math.min(255, b * 1.30 + 16)];
}

function setTargetsFromData(data, scene, snap = false) {
  const geo = geometryFor(data, scene);
  const points = data.points;
  if (!points.length) return;
  for (let i = 0; i < state.particles.length; i += 1) {
    const target = points[i % points.length];
    const jitter = target[7] ? 0.16 : target[5] > 184 ? 0.42 : 0.9;
    const p = state.particles[i];
    p.tx = geo.left + target[0] / 1023 * geo.sourceWidth * geo.scale + (Math.random() - 0.5) * jitter;
    p.ty = geo.top + target[1] / 1023 * geo.sourceHeight * geo.scale + (Math.random() - 0.5) * jitter;
    p.rgb = [target[2], target[3], target[4]];
    p.water = target[6] === 1;
    p.edge = target[7] === 1;
    p.intensity = Math.min(1, target[5] / 255 + (p.edge ? 0.16 : 0));
    p.size = p.water ? 0.55 + Math.random() * 0.85 : p.edge ? 0.72 + Math.random() * 0.86 : 0.48 + Math.random() * 0.84;
    if (snap) {
      p.x = p.tx;
      p.y = p.ty;
      p.vx = 0;
      p.vy = 0;
    }
  }
}

function setScene(scene, snap = false) {
  if (!scenes.includes(scene)) return;
  state.scene = scene;
  state.sceneStarted = performance.now();
  state.transitionUntil = performance.now() + (snap ? 0 : 650);
  state.particles.forEach(p => { p.water = false; p.edge = false; });
  if (particleData[scene]) setTargetsFromData(particleData[scene], scene, snap);
  document.querySelectorAll('.scene-btn').forEach(button => button.classList.toggle('active', button.dataset.scene === scene));
  document.getElementById('statusText').textContent = labels[scene];
}

function draw(time) {
  ctx.fillStyle = 'rgba(3, 5, 10, 0.38)';
  ctx.fillRect(0, 0, W, H);
  if (state.hand) {
    state.view.targetX = (state.hand.x / W - 0.5) * 1.35;
    state.view.targetY = (state.hand.y / H - 0.5) * 0.75;
  }
  state.view.x += (state.view.targetX - state.view.x) * 0.08;
  state.view.y += (state.view.targetY - state.view.y) * 0.08;
  const pointerX = state.mouse.active ? state.mouse.x : (state.hand?.x ?? -999);
  const pointerY = state.mouse.active ? state.mouse.y : (state.hand?.y ?? -999);
  const sceneSpring = performance.now() < state.transitionUntil ? Math.max(state.settings.spring, 0.12) : state.settings.spring;
  for (const p of state.particles) {
    const waterWave = Math.sin(time * 0.0025 + p.tx * 0.055 + p.seed) + Math.sin(time * 0.0013 + p.tx * 0.021);
    const waterFlowX = p.water ? Math.sin(time * 0.0022 + p.seed * 0.7) * 10 + Math.cos(time * 0.0011 + p.ty * 0.025) * 4 : 0;
    const waterFlowY = p.water ? waterWave * 2.7 + Math.cos(time * 0.0017 + p.seed * 0.4) * 1.4 : 0;
    const edgeStability = p.edge ? 0.68 : 1;
    const motionBoost = p.water ? 1 : 1.75;
    const ambientFlowX = (Math.sin(time * 0.00105 + p.seed * 1.7 + p.ty * 0.012) * 1.42 + Math.cos(time * 0.00058 + p.tx * 0.009) * 0.68) * edgeStability * motionBoost;
    const ambientFlowY = (Math.cos(time * 0.00092 + p.seed * 1.3 + p.tx * 0.01) * 0.72 + Math.sin(time * 0.00047 + p.ty * 0.02) * 0.32) * edgeStability * motionBoost;
    const edgeBreath = p.edge ? Math.sin(time * 0.0014 + p.seed) * 0.12 : 0;
    const parallaxX = state.view.x * (p.ty - H / 2) * 0.10;
    const parallaxY = state.view.y * (p.tx - W / 2) * 0.035;
    p.vx += (p.tx + waterFlowX + ambientFlowX + parallaxX - p.x) * sceneSpring;
    p.vy += (p.ty + waterFlowY + ambientFlowY + edgeBreath + parallaxY - p.y) * sceneSpring;
    const dx = p.x - pointerX;
    const dy = p.y - pointerY;
    const distance = Math.hypot(dx, dy) || 1;
    if ((state.mouse.active || state.hand) && distance < 170) {
      const force = (1 - distance / 170) * state.settings.repel * (state.mouse.down ? 2.9 : 1);
      p.vx += dx / distance * force;
      p.vy += dy / distance * force;
    }
    p.vx *= p.water ? 0.95 : 0.93;
    p.vy *= p.water ? 0.95 : 0.93;
    p.x += p.vx;
    p.y += p.vy;
    const twinkle = 0.55 + Math.sin(time * 0.002 + p.seed) * 0.25;
    const alpha = p.water ? 0.72 + twinkle * 0.22 : p.edge ? Math.min(1, 0.24 + p.intensity * 0.92 + twinkle * 0.14) : Math.min(0.98, 0.08 + p.intensity * 0.86 + twinkle * 0.12);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = `rgb(${p.rgb[0]}, ${p.rgb[1]}, ${p.rgb[2]})`;
    ctx.shadowBlur = state.mouse.down ? 8 : (p.water ? 2 : 0);
    ctx.shadowColor = ctx.fillStyle;
    const size = p.size * (twinkle + 0.62);
    ctx.fillRect(p.x - size / 2, p.y - size / 2, size, size);
  }
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  if (performance.now() - state.sceneStarted > 10000) setScene(scenes[(scenes.indexOf(state.scene) + 1) % scenes.length]);
  requestAnimationFrame(draw);
}

function handlePointer(event) {
  const rect = canvas.getBoundingClientRect();
  const point = event.touches?.[0] || event;
  const x = point.clientX - rect.left;
  const y = point.clientY - rect.top;
  if (state.view.dragging) {
    state.view.targetX = Math.max(-1.2, Math.min(1.2, state.view.targetX + (x - state.view.lastX) * 0.006));
    state.view.targetY = Math.max(-0.7, Math.min(0.7, state.view.targetY + (y - state.view.lastY) * 0.004));
  }
  state.view.lastX = x;
  state.view.lastY = y;
  state.mouse.x = x;
  state.mouse.y = y;
  state.mouse.active = state.mouseEnabled;
  state.mouse.down = event.type === 'pointerdown';
}

canvas.addEventListener('pointermove', handlePointer);
canvas.addEventListener('pointerdown', event => { state.view.dragging = true; handlePointer(event); });
canvas.addEventListener('pointerup', () => { state.view.dragging = false; state.mouse.down = false; });
canvas.addEventListener('pointerleave', () => { state.view.dragging = false; state.mouse.active = false; });
canvas.addEventListener('click', () => {
  for (const p of state.particles) {
    const dx = p.x - state.mouse.x;
    const dy = p.y - state.mouse.y;
    const distance = Math.hypot(dx, dy);
    if (distance < 130) { p.vx += dx / (distance || 1) * 8; p.vy += dy / (distance || 1) * 8; }
  }
});

document.querySelectorAll('.scene-btn').forEach(button => button.addEventListener('click', () => setScene(button.dataset.scene)));

function wireSlider(id, key, output, formatter) {
  const input = document.getElementById(id);
  input.addEventListener('input', () => {
    state.settings[key] = Number(input.value);
    document.getElementById(output).textContent = formatter(state.settings[key]);
    if (key === 'count') createParticles();
  });
}
wireSlider('countSlider', 'count', 'countValue', value => value.toLocaleString());
wireSlider('repelSlider', 'repel', 'repelValue', value => value.toFixed(2));
wireSlider('springSlider', 'spring', 'springValue', value => value.toFixed(3));

document.querySelectorAll('.toggle').forEach(button => button.addEventListener('click', async () => {
  const key = button.dataset.target;
  state[key] = !state[key];
  button.classList.toggle('on', state[key]);
  if (key === 'mouseEnabled' && !state[key]) state.mouse.active = false;
  if (key === 'cameraEnabled') await toggleCamera(state[key]);
}));

document.getElementById('resetBtn').addEventListener('click', () => {
  state.view.targetX = 0;
  state.view.targetY = 0;
  setScene(state.scene, true);
});

async function toggleCamera(on) {
  const badge = document.getElementById('cameraBadge');
  const hint = document.getElementById('cameraHint');
  if (!on) {
    if (stream) stream.getTracks().forEach(track => track.stop());
    stream = null;
    state.hand = null;
    badge.textContent = 'CAMERA OFF';
    badge.classList.remove('active');
    hint.textContent = '食指控制视角与粒子场';
    return;
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 640, height: 480 } });
    const video = document.getElementById('cameraVideo');
    video.srcObject = stream;
    badge.textContent = 'CAMERA ACTIVE';
    badge.classList.add('active');
    hint.textContent = '摄像头已连接 · 手势控制开启';
    if (window.Hands && window.Camera) {
      const hands = new Hands({ locateFile: file => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}` });
      hands.setOptions({ maxNumHands: 1, modelComplexity: 0, minDetectionConfidence: 0.55, minTrackingConfidence: 0.55 });
      hands.onResults(result => {
        const finger = result.multiHandLandmarks?.[0]?.[8];
        state.hand = finger ? { x: (1 - finger.x) * W, y: finger.y * H } : null;
      });
      new Camera(video, { onFrame: async () => hands.send({ image: video }), width: 640, height: 480 }).start();
    }
  } catch (error) {
    state.cameraEnabled = false;
    document.getElementById('cameraToggle').classList.remove('on');
    badge.textContent = 'CAMERA ERROR';
    hint.textContent = '请允许浏览器访问摄像头';
  }
}

window.addEventListener('resize', resize);
resize();
setScene(state.scene, true);
requestAnimationFrame(draw);
