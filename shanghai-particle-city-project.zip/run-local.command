#!/bin/zsh
cd "$(dirname "$0")"
echo "上海粒子城市已启动： http://localhost:8000"
python3 -m http.server 8000 >/tmp/shanghai-particle-city-server.log 2>&1 &
server_pid=$!
trap 'kill "$server_pid" 2>/dev/null' EXIT INT TERM
sleep 1
open "http://localhost:8000/"
wait "$server_pid"
